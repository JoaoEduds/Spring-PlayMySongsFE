
async function buscaMusica() {
    const termo = document.getElementById("busca").value;
    const url = `http://localhost:8080/apis/find-musics?busca=${encodeURIComponent(termo)}`;

    try {
        const resposta = await fetch(url);
        const dados = await resposta.json();

        const resultDiv = document.getElementById("result");
        resultDiv.innerHTML = ""; // Limpa os resultados anteriores

        if (resposta.ok) {
            if (Array.isArray(dados) && dados.length > 0) {
        resultDiv.innerHTML = ""; // Limpa os resultados anteriores

        dados.forEach(music => {
            console.log("URL da música:", music.fileName); // Verificando no console

            resultDiv.innerHTML += `
                <p>
                    🎵 <strong>${music.titulo}</strong> - ${music.artista} 
                    (${music.estilo}) 
                    <br>
                    <audio controls>
                        <source src="${music.fileName}" type="audio/mpeg">
                        Seu navegador não suporta o elemento de áudio.
                    </audio>
                    <br>
                </p>
            `;
        });
            } else {
                resultDiv.innerHTML = "<p>Nenhuma música encontrada.</p>";
            }
        } else {
            resultDiv.innerHTML = `<p style="color:red;">Erro: ${dados.mensagem || "Falha na busca"}</p>`;
        }
    } catch (erro) {
        console.error("Erro ao buscar músicas:", erro);
    }
}






async function cadMusica() {
    const form = document.getElementById("fmusica");
    const formData = new FormData(form);

    try {
        const resposta = await fetch("http://localhost:8080/apis/add-music", {
            method: "POST",
            body: formData
        });

        const resultado = await resposta.json();
        console.log(resultado);

        if (resposta.ok) {
            alert("Música cadastrada com sucesso!");
            buscaMusica(); // Atualiza a lista automaticamente após cadastrar
        } else {
            alert("Erro: " + (resultado.mensagem || "Erro desconhecido"));
        }
    } catch (erro) {
        console.error("Erro ao cadastrar música:", erro);
        alert("Falha ao cadastrar música.");
    }
}

